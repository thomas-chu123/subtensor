hashcat 'SCRYPT:1024:1:1:MDIwMzMwNTQwNDQyNQ==:5FW+zWivLxgCWj7qLiQbeC8zaNQ+qdO0NUinvqyFcfo=^C-a 3 -D 2 -m 8900 -1 '' '?1?1?1?1?1?1?1' -w 3 --potfile-disable
